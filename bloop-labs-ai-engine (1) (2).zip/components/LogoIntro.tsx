'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'

export default function LogoIntro() {
  const [phase, setPhase] = useState<'visible' | 'exiting' | 'done'>('visible')

  useEffect(() => {
    // Start exit animation at 2.2s, unmount at 2.8s
    const exitTimer = setTimeout(() => setPhase('exiting'), 2200)
    const doneTimer = setTimeout(() => setPhase('done'), 2800)
    return () => {
      clearTimeout(exitTimer)
      clearTimeout(doneTimer)
    }
  }, [])

  if (phase === 'done') return null

  return (
    <div
      className={`intro-overlay${phase === 'exiting' ? ' exiting' : ''}`}
      aria-hidden="true"
    >
      {/* Subtle radial glow behind the logo */}
      <div
        style={{
          position: 'absolute',
          width: '340px',
          height: '340px',
          borderRadius: '50%',
          background:
            'radial-gradient(circle, rgba(59,130,246,0.18) 0%, rgba(99,102,241,0.08) 50%, transparent 70%)',
          pointerEvents: 'none',
        }}
      />

      {/* Logo image */}
      <Image
        src="/blooplabs-logo.png"
        alt="BloopLabs logo"
        width={140}
        height={140}
        priority
        className="intro-logo-img"
        style={{ position: 'relative', zIndex: 1 }}
      />

      {/* Brand name */}
      <span className="intro-logo-text" style={{ position: 'relative', zIndex: 1 }}>
        BloopLabs
      </span>

      {/* Tagline */}
      <span className="intro-tagline" style={{ position: 'relative', zIndex: 1 }}>
        AI-Powered Idea Engine
      </span>

      {/* Bottom progress bar */}
      <div className="intro-progress-bar" />
    </div>
  )
}
