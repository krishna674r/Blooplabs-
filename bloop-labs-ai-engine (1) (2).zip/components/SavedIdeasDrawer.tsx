'use client'

import { useState, useEffect } from 'react'
import { Bookmark, X, Trash2, ChevronRight, ExternalLink } from 'lucide-react'
import type { StartupIdea } from '@/services/geminiService'

interface SavedIdea extends StartupIdea {
  id: string
  created_at: string
}

interface SavedIdeasDrawerProps {
  sessionId: string
  refreshTrigger: number
}

export default function SavedIdeasDrawer({ sessionId, refreshTrigger }: SavedIdeasDrawerProps) {
  const [open, setOpen] = useState(false)
  const [ideas, setIdeas] = useState<SavedIdea[]>([])
  const [loading, setLoading] = useState(false)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [deleting, setDeleting] = useState<string | null>(null)

  // Load saved ideas from Supabase via client
  useEffect(() => {
    if (!sessionId) return
    const load = async () => {
      setLoading(true)
      try {
        const { createClient } = await import('@/lib/supabase/client')
        const supabase = createClient()
        const { data } = await supabase
          .from('saved_ideas')
          .select('*')
          .eq('session_id', sessionId)
          .order('created_at', { ascending: false })
        setIdeas((data as SavedIdea[]) ?? [])
      } catch {
        // silently fail
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [sessionId, refreshTrigger])

  const handleDelete = async (id: string) => {
    setDeleting(id)
    try {
      const res = await fetch('/api/save-idea', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, sessionId }),
      })
      if (res.ok) {
        setIdeas((prev) => prev.filter((i) => i.id !== id))
        if (expanded === id) setExpanded(null)
      }
    } finally {
      setDeleting(null)
    }
  }

  const count = ideas.length

  return (
    <>
      {/* Trigger Button */}
      <button
        onClick={() => setOpen(true)}
        className="relative flex items-center gap-2 px-3 py-1.5 rounded-xl border border-white/10 bg-white/[0.05] hover:bg-white/[0.09] text-slate-400 hover:text-slate-200 text-sm transition-all duration-150"
        aria-label="Open saved ideas"
      >
        <Bookmark className="w-4 h-4" />
        <span className="hidden sm:inline font-medium">Saved</span>
        {count > 0 && (
          <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-indigo-500 text-white text-[10px] font-bold flex items-center justify-center">
            {count > 9 ? '9+' : count}
          </span>
        )}
      </button>

      {/* Backdrop */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
          onClick={() => setOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Drawer Panel */}
      <div
        className={`fixed top-0 right-0 h-full w-full sm:w-[420px] z-50 flex flex-col
          bg-[#0a111f] border-l border-white/[0.08]
          transform transition-transform duration-300 ease-out
          ${open ? 'translate-x-0' : 'translate-x-full'}`}
        role="dialog"
        aria-label="Saved Ideas"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.07]">
          <div className="flex items-center gap-2.5">
            <Bookmark className="w-4 h-4 text-indigo-400" />
            <h2 className="text-sm font-semibold text-slate-200">Saved Ideas</h2>
            {count > 0 && (
              <span className="px-1.5 py-0.5 rounded-md bg-indigo-500/20 border border-indigo-400/20 text-indigo-300 text-xs font-medium">
                {count}
              </span>
            )}
          </div>
          <button
            onClick={() => setOpen(false)}
            className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-300 hover:bg-white/[0.06] transition-colors"
            aria-label="Close drawer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
          {loading && (
            <div className="flex items-center justify-center py-12">
              <div className="flex gap-1.5">
                <span className="bloop-dot w-2 h-2 rounded-full bg-indigo-400" />
                <span className="bloop-dot w-2 h-2 rounded-full bg-blue-400" />
                <span className="bloop-dot w-2 h-2 rounded-full bg-indigo-400" />
              </div>
            </div>
          )}

          {!loading && count === 0 && (
            <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
              <div className="w-12 h-12 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center">
                <Bookmark className="w-5 h-5 text-slate-600" />
              </div>
              <p className="text-slate-500 text-sm">No saved ideas yet.</p>
              <p className="text-slate-600 text-xs max-w-[200px] leading-relaxed">
                Hit the bookmark icon on any generated idea to save it here.
              </p>
            </div>
          )}

          {!loading && ideas.map((idea) => (
            <div
              key={idea.id}
              className="rounded-xl border border-white/[0.07] bg-white/[0.03] overflow-hidden"
            >
              {/* Idea Header Row */}
              <div className="flex items-start gap-3 p-4">
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-semibold text-slate-200 truncate">{idea.title}</h3>
                  <p className="text-xs text-slate-500 mt-0.5 line-clamp-2 leading-relaxed">{idea.tagline}</p>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <button
                    onClick={() => setExpanded(expanded === idea.id ? null : idea.id)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-300 hover:bg-white/[0.06] transition-colors"
                    aria-label="Expand idea"
                  >
                    <ChevronRight
                      className={`w-3.5 h-3.5 transition-transform duration-200 ${expanded === idea.id ? 'rotate-90' : ''}`}
                    />
                  </button>
                  <button
                    onClick={() => handleDelete(idea.id)}
                    disabled={deleting === idea.id}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-600 hover:text-red-400 hover:bg-red-500/10 transition-colors disabled:opacity-40"
                    aria-label="Delete saved idea"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Expanded Detail */}
              {expanded === idea.id && (
                <div className="px-4 pb-4 space-y-3 border-t border-white/[0.06] pt-3">
                  <div>
                    <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider mb-1">Problem</p>
                    <p className="text-xs text-slate-400 leading-relaxed">{idea.the_problem}</p>
                  </div>
                  <div>
                    <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider mb-1">Solution</p>
                    <p className="text-xs text-slate-400 leading-relaxed">{idea.the_solution}</p>
                  </div>
                  <div>
                    <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider mb-1.5">First Steps</p>
                    <ol className="space-y-1.5">
                      {idea.first_three_steps.map((step, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="flex-shrink-0 w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-400 text-[10px] font-bold flex items-center justify-center mt-0.5">
                            {i + 1}
                          </span>
                          <span className="text-xs text-slate-400 leading-relaxed">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-white/[0.07]">
          <p className="text-[11px] text-slate-600 text-center">
            Ideas are saved to your browser session &middot; <ExternalLink className="w-3 h-3 inline" /> Powered by Supabase
          </p>
        </div>
      </div>
    </>
  )
}
