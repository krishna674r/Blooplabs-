'use client'

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface FilterDropdownProps {
  placeholder: string
  options: string[]
  value: string
  onChange: (value: string) => void
  disabled?: boolean
}

export default function FilterDropdown({
  placeholder,
  options,
  value,
  onChange,
  disabled = false,
}: FilterDropdownProps) {
  return (
    <Select value={value} onValueChange={onChange} disabled={disabled}>
      <SelectTrigger
        className="
          h-10 rounded-xl border border-white/10
          bg-white/5 backdrop-blur-sm
          text-slate-300 text-sm
          hover:bg-white/8 hover:border-white/15
          focus:ring-1 focus:ring-indigo-500/50 focus:border-indigo-500/50
          transition-all duration-150
          disabled:opacity-40 disabled:cursor-not-allowed
          min-w-[140px]
        "
      >
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent
        className="
          bg-[#0f172a] border border-white/10 rounded-xl
          shadow-xl shadow-black/50 backdrop-blur-xl
          text-slate-300
        "
      >
        {options.map((option) => (
          <SelectItem
            key={option}
            value={option}
            className="
              text-sm text-slate-300 rounded-lg
              focus:bg-indigo-500/20 focus:text-white
              cursor-pointer
            "
          >
            {option}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
