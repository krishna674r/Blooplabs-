'use client'

import { type StartupIdea } from '@/services/geminiService'
import {
  Lightbulb,
  Target,
  Wrench,
  DollarSign,
  Users,
  Zap,
  Database,
  Globe,
  ChevronRight,
  Cpu,
} from 'lucide-react'

interface IdeaCardProps {
  idea: StartupIdea
}

export default function IdeaCard({ idea }: IdeaCardProps) {
  return (
    <div className="w-full fade-in-up space-y-4">
      {/* Title & Tagline Hero Card */}
      <div className="relative overflow-hidden rounded-2xl glass card-lift p-6 md:p-8 border border-white/10">
        {/* Subtle glow overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 via-transparent to-blue-500/5 pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-start gap-3 mb-3">
            <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center">
              <Cpu className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <p className="text-xs font-medium text-indigo-400 uppercase tracking-widest mb-1">
                Idea Generated
              </p>
              <h2 className="text-3xl md:text-4xl font-bold gradient-text leading-tight text-balance">
                {idea.title}
              </h2>
            </div>
          </div>
          <p className="text-lg text-slate-300 font-medium mt-4 leading-relaxed">
            &ldquo;{idea.tagline}&rdquo;
          </p>
        </div>
      </div>

      {/* Problem & Solution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-2xl glass card-lift p-5 border border-white/8">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-red-500/15 border border-red-400/20 flex items-center justify-center">
              <Target className="w-4 h-4 text-red-400" />
            </div>
            <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
              The Problem
            </h3>
          </div>
          <p className="text-slate-400 leading-relaxed text-sm">{idea.the_problem}</p>
        </div>

        <div className="rounded-2xl glass card-lift p-5 border border-white/8">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-400/20 flex items-center justify-center">
              <Lightbulb className="w-4 h-4 text-emerald-400" />
            </div>
            <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
              The Solution
            </h3>
          </div>
          <p className="text-slate-400 leading-relaxed text-sm">{idea.the_solution}</p>
        </div>
      </div>

      {/* Target Audience */}
      <div className="rounded-2xl glass card-lift p-5 border border-white/8">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-blue-500/15 border border-blue-400/20 flex items-center justify-center">
            <Users className="w-4 h-4 text-blue-400" />
          </div>
          <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
            Target Audience
          </h3>
        </div>
        <p className="text-slate-400 leading-relaxed text-sm">{idea.target_audience}</p>
      </div>

      {/* Monetization & Free Build Stack */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-2xl glass card-lift p-5 border border-white/8">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-yellow-500/15 border border-yellow-400/20 flex items-center justify-center">
              <DollarSign className="w-4 h-4 text-yellow-400" />
            </div>
            <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
              Monetization
            </h3>
          </div>
          <ul className="space-y-2">
            {idea.monetization.map((stream, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="flex-shrink-0 w-5 h-5 rounded-full bg-yellow-500/20 text-yellow-400 text-xs flex items-center justify-center font-bold mt-0.5">
                  {i + 1}
                </span>
                <span className="text-slate-400 text-sm leading-relaxed">{stream}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-2xl glass card-lift p-5 border border-white/8">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-purple-500/15 border border-purple-400/20 flex items-center justify-center">
              <Wrench className="w-4 h-4 text-purple-400" />
            </div>
            <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
              Free Build Stack
            </h3>
          </div>
          <div className="space-y-3">
            <StackItem icon={<Globe className="w-3.5 h-3.5 text-sky-400" />} label="Frontend" value={idea.free_build_stack.frontend} />
            <StackItem icon={<Database className="w-3.5 h-3.5 text-emerald-400" />} label="Database" value={idea.free_build_stack.database} />
            <StackItem icon={<Zap className="w-3.5 h-3.5 text-amber-400" />} label="Automation" value={idea.free_build_stack.automation} />
          </div>
        </div>
      </div>

      {/* First 3 Steps */}
      <div className="rounded-2xl glass card-lift p-5 md:p-6 border border-white/8">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/15 border border-indigo-400/20 flex items-center justify-center">
            <ChevronRight className="w-4 h-4 text-indigo-400" />
          </div>
          <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
            Your First 3 Steps
          </h3>
        </div>
        <ol className="space-y-4">
          {idea.first_three_steps.map((step, i) => (
            <li key={i} className="flex items-start gap-4">
              <span className="flex-shrink-0 w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500/30 to-blue-500/20 border border-indigo-400/30 text-indigo-300 text-sm font-bold flex items-center justify-center">
                {i + 1}
              </span>
              <p className="text-slate-400 text-sm leading-relaxed pt-1.5">{step}</p>
            </li>
          ))}
        </ol>
      </div>
    </div>
  )
}

function StackItem({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode
  label: string
  value: string
}) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="flex-shrink-0 w-6 h-6 rounded-md bg-white/5 flex items-center justify-center">
        {icon}
      </div>
      <div className="min-w-0">
        <span className="text-xs text-slate-500 block leading-none mb-0.5">{label}</span>
        <span className="text-sm text-slate-300 font-medium">{value}</span>
      </div>
    </div>
  )
}
