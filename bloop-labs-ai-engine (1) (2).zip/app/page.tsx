'use client'

import { useState, useCallback, useEffect } from 'react'
import Image from 'next/image'
import { Sparkles, Shuffle, Loader2, AlertCircle, FlaskConical, EyeOff } from 'lucide-react'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import FilterDropdown from '@/components/FilterDropdown'
import IdeaCard from '@/components/IdeaCard'
import LogoIntro from '@/components/LogoIntro'
import type { StartupIdea } from '@/services/geminiService'

// ─── Filter Options ──────────────────────────────────────────────────────────
const CATEGORIES = [
  'Any Category',
  'Software / SaaS',
  'Hardware / IoT',
  'AI & Machine Learning',
  'Mobile App',
  'No-Code / Low-Code',
  'Web3 / Blockchain',
  'Deep Tech / R&D',
  'Open Source Tool',
]

const SDGS = [
  'Any SDG',
  'SDG 1 — No Poverty',
  'SDG 2 — Zero Hunger',
  'SDG 3 — Good Health & Well-being',
  'SDG 4 — Quality Education',
  'SDG 5 — Gender Equality',
  'SDG 6 — Clean Water & Sanitation',
  'SDG 7 — Affordable & Clean Energy',
  'SDG 8 — Decent Work & Economic Growth',
  'SDG 9 — Industry, Innovation & Infrastructure',
  'SDG 10 — Reduced Inequalities',
  'SDG 11 — Sustainable Cities',
  'SDG 12 — Responsible Consumption',
  'SDG 13 — Climate Action',
  'SDG 17 — Partnerships for Goals',
]

const DIFFICULTIES = [
  'Any Difficulty',
  'Beginner',
  'Intermediate',
  'Advanced',
]

const AGE_GROUPS = [
  'Any Age Group',
  '13-17 (Teen)',
  '18-22 (College)',
  '23-28 (Early Career)',
  '29+ (Professional)',
]

// ─── Remix Combos ────────────────────────────────────────────────────────────
const REMIX_COMBOS = [
  'Local restaurant supply chain + WhatsApp automation',
  'Plumbing businesses + recurring revenue SaaS',
  'School tutoring centers + scheduling software',
  'Barbershop owners + loyalty programs',
  'Freelance photographers + invoice tracking',
  'Gym trainers + client progress dashboards',
  'Food truck vendors + pre-order systems',
  'Rural pharmacies + prescription reminders',
  'Event planners + vendor management tools',
  'Car mechanics + digital inspection reports',
  'Wedding venues + deposit automation',
  'Trucking companies + driver compliance logs',
]

// ─── Loading Messages ─────────────────────────────────────────────────────────
const LOADING_MESSAGES = [
  'Scanning market gaps...',
  'Roasting generic ideas...',
  'Identifying unsexy problems...',
  'Consulting the innovation engine...',
  'Running VC stress tests...',
  'Filtering out the clichés...',
  'Finding the boring goldmine...',
  'Calculating zero-budget feasibility...',
]

type AppState = 'idle' | 'loading' | 'success' | 'error'

export default function Home() {
  const [prompt, setPrompt] = useState('')
  const [category, setCategory] = useState('Any Category')
  const [sdg, setSdg] = useState('Any SDG')
  const [difficulty, setDifficulty] = useState('Any Difficulty')
  const [ageGroup, setAgeGroup] = useState('Any Age Group')
  const [stealthMode, setStealthMode] = useState(false)

  const [appState, setAppState] = useState<AppState>('idle')
  const [idea, setIdea] = useState<StartupIdea | null>(null)
  const [errorMsg, setErrorMsg] = useState('')
  const [loadingText, setLoadingText] = useState(LOADING_MESSAGES[0])

  // Cycle loading messages
  useEffect(() => {
    if (appState !== 'loading') return
    let i = 0
    const interval = setInterval(() => {
      i = (i + 1) % LOADING_MESSAGES.length
      setLoadingText(LOADING_MESSAGES[i])
    }, 1800)
    return () => clearInterval(interval)
  }, [appState])

  const handleRemix = useCallback(() => {
    const random = REMIX_COMBOS[Math.floor(Math.random() * REMIX_COMBOS.length)]
    setPrompt(random)
  }, [])

  const handleGenerate = useCallback(async () => {
    if (appState === 'loading') return
    setAppState('loading')
    setIdea(null)
    setErrorMsg('')
    setLoadingText(LOADING_MESSAGES[0])

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, category, sdg, difficulty, ageGroup, stealthMode }),
      })

      const data = await res.json()

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Something went wrong.')
      }

      setIdea(data.idea)
      setAppState('success')
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to generate idea.'
      setErrorMsg(msg)
      setAppState('error')
    }
  }, [prompt, category, sdg, difficulty, ageGroup, stealthMode, appState])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleGenerate()
  }

  return (
    <>
      {/* ── Intro Animation Overlay ─────────────────────────────── */}
      <LogoIntro />

      <div className="min-h-screen bg-[#030712] bg-radial-glow">
        <div className="max-w-4xl mx-auto px-4 pb-24 pt-6 md:px-6">

          {/* ── Header ──────────────────────────────────────────── */}
          <header className="flex items-center justify-between py-4 mb-12 md:mb-16">
            <div className="flex items-center gap-3">
              <Image
                src="/blooplabs-logo.png"
                alt="BloopLabs logo"
                width={36}
                height={36}
                className="object-contain"
                style={{ filter: 'drop-shadow(0 0 8px rgba(59,130,246,0.5))' }}
              />
              <span className="text-xl font-bold tracking-tight gradient-text">BloopLabs</span>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-indigo-400/20 bg-indigo-500/[0.08]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs text-slate-400 font-medium">AI Engine Online</span>
            </div>
          </header>

          {/* ── Hero Section ──────────────────────────────────────── */}
          <section className="text-center mb-12 md:mb-14">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-indigo-400/20 bg-indigo-500/[0.08] text-xs text-indigo-300 font-medium mb-5">
              <Sparkles className="w-3 h-3" />
              Zero-budget ideas for real founders
            </div>
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight leading-tight text-balance mb-4">
              <span className="text-slate-100">Find your</span>{' '}
              <span className="gradient-text">next big idea.</span>
            </h1>
            <p className="text-base md:text-lg text-slate-400 max-w-xl mx-auto leading-relaxed text-pretty">
              BloopLabs generates hyper-specific, unsexy, actionable startup ideas tailored for
              students and young creators with zero budget.
            </p>
          </section>

          {/* ── Engine Section ────────────────────────────────────── */}
          <section className="glass rounded-2xl border border-white/10 p-5 md:p-7 space-y-5 mb-8">

            {/* Input Row */}
            <div className="flex gap-2.5">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="e.g. local restaurants, fitness trainers, B2B logistics..."
                  disabled={appState === 'loading'}
                  className="
                    w-full h-12 rounded-xl px-4 text-sm
                    bg-white/[0.06] border border-white/[0.12]
                    text-slate-100 placeholder-slate-500
                    focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/40
                    hover:bg-white/[0.08] hover:border-white/[0.16]
                    transition-all duration-150
                    disabled:opacity-40 disabled:cursor-not-allowed
                  "
                />
              </div>

              {/* Remix Button */}
              <button
                onClick={handleRemix}
                disabled={appState === 'loading'}
                title="Remix: pick a random industry combo"
                className="
                  h-12 w-12 flex-shrink-0 rounded-xl
                  bg-white/[0.06] border border-white/[0.12]
                  text-slate-400 hover:text-slate-200
                  hover:bg-white/[0.10] hover:border-white/[0.20]
                  flex items-center justify-center
                  transition-all duration-150
                  disabled:opacity-40 disabled:cursor-not-allowed
                "
              >
                <Shuffle className="w-4 h-4" />
              </button>
            </div>

            {/* Filter Row */}
            <div className="flex flex-wrap gap-2.5">
              <FilterDropdown
                placeholder="Category"
                options={CATEGORIES}
                value={category}
                onChange={setCategory}
                disabled={appState === 'loading'}
              />
              <FilterDropdown
                placeholder="SDG Alignment"
                options={SDGS}
                value={sdg}
                onChange={setSdg}
                disabled={appState === 'loading'}
              />
              <FilterDropdown
                placeholder="Difficulty"
                options={DIFFICULTIES}
                value={difficulty}
                onChange={setDifficulty}
                disabled={appState === 'loading'}
              />
              <FilterDropdown
                placeholder="Age Group"
                options={AGE_GROUPS}
                value={ageGroup}
                onChange={setAgeGroup}
                disabled={appState === 'loading'}
              />
            </div>

            {/* Stealth Mode + Generate Button Row */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-1">

              {/* Stealth Mode Toggle */}
              <div className="flex items-center gap-3">
                <Switch
                  id="stealth-mode"
                  checked={stealthMode}
                  onCheckedChange={setStealthMode}
                  disabled={appState === 'loading'}
                  className="data-[state=checked]:bg-indigo-600"
                />
                <div className="flex items-center gap-1.5">
                  <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                  <Label
                    htmlFor="stealth-mode"
                    className="text-sm text-slate-400 cursor-pointer select-none"
                  >
                    Stealth Mode
                  </Label>
                  <span className="hidden sm:inline text-xs text-slate-600 ml-1">
                    — B2B enterprise only
                  </span>
                </div>
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerate}
                disabled={appState === 'loading'}
                className="
                  glow-btn
                  flex items-center gap-2 px-6 py-3 rounded-xl
                  bg-gradient-to-r from-indigo-600 to-blue-600
                  hover:from-indigo-500 hover:to-blue-500
                  text-white font-semibold text-sm
                  transition-all duration-150
                  disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none
                  shadow-lg shadow-indigo-500/25
                  w-full sm:w-auto justify-center
                "
              >
                {appState === 'loading' ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Generate Idea
                  </>
                )}
              </button>
            </div>
          </section>

          {/* ── Output Area ───────────────────────────────────────── */}
          <section aria-live="polite" aria-atomic="false">

            {/* Loading State */}
            {appState === 'loading' && (
              <div className="flex flex-col items-center justify-center py-20 gap-5 fade-in-up">
                <div className="flex gap-2">
                  <span className="bloop-dot w-2.5 h-2.5 rounded-full bg-indigo-400" />
                  <span className="bloop-dot w-2.5 h-2.5 rounded-full bg-blue-400" />
                  <span className="bloop-dot w-2.5 h-2.5 rounded-full bg-indigo-400" />
                </div>
                <p className="text-slate-400 text-sm font-medium">
                  {loadingText}
                </p>
              </div>
            )}

            {/* Error State */}
            {appState === 'error' && (
              <div className="fade-in-up rounded-2xl glass border border-red-500/20 p-5 flex items-start gap-3">
                <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-red-500/15 flex items-center justify-center">
                  <AlertCircle className="w-4 h-4 text-red-400" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-red-300 mb-1">Generation Failed</p>
                  <p className="text-sm text-slate-500 leading-relaxed">{errorMsg}</p>
                  <button
                    onClick={handleGenerate}
                    className="mt-3 text-xs text-indigo-400 hover:text-indigo-300 underline underline-offset-2 transition-colors"
                  >
                    Try again
                  </button>
                </div>
              </div>
            )}

            {/* Idle / Empty State */}
            {appState === 'idle' && (
              <div className="flex flex-col items-center justify-center py-20 gap-4 text-center fade-in-up">
                <div className="w-16 h-16 rounded-2xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center mb-2">
                  <FlaskConical className="w-7 h-7 text-slate-600" />
                </div>
                <p className="text-slate-400 text-sm font-medium">Your startup idea will appear here.</p>
                <p className="text-slate-600 text-xs max-w-xs leading-relaxed">
                  Enter a prompt or hit the remix button to get started. The engine avoids
                  clichés and hunts for real, unsexy problems worth solving.
                </p>
              </div>
            )}

            {/* Success State */}
            {appState === 'success' && idea && (
              <IdeaCard idea={idea} />
            )}
          </section>

          {/* ── Footer ────────────────────────────────────────────── */}
          <footer className="mt-20 text-center">
            <p className="text-xs text-slate-700">
              Built for builders who ship.{' '}
              <span className="gradient-text font-medium">BloopLabs</span>
              {' '}&mdash; powered by Gemini 2.5 Flash.
            </p>
          </footer>

        </div>
      </div>
    </>
  )
}
