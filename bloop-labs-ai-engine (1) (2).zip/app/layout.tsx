import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import './globals.css'

const geist = Geist({
  subsets: ['latin'],
  variable: '--font-geist-sans',
})

const geistMono = Geist_Mono({
  subsets: ['latin'],
  variable: '--font-geist-mono',
})

export const metadata: Metadata = {
  title: 'BloopLabs — AI-Powered Startup Idea Engine',
  description:
    'Generate hyper-unique, zero-budget, real-world startup ideas powered by AI. Built for students and young creators.',
  keywords: ['startup ideas', 'AI', 'innovation', 'zero budget', 'student entrepreneur'],
  authors: [{ name: 'BloopLabs' }],
  openGraph: {
    title: 'BloopLabs — AI-Powered Startup Idea Engine',
    description: 'Generate hyper-unique startup ideas for students and creators.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#030712',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${geist.variable} ${geistMono.variable} bg-[#030712]`}>
      <body className="font-sans antialiased bg-[#030712] text-slate-100 min-h-screen">
        {children}
      </body>
    </html>
  )
}
