import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import type { StartupIdea } from '@/services/geminiService'

export const runtime = 'nodejs'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { idea, sessionId, prompt, category, sdg, difficulty, ageGroup } = body as {
      idea: StartupIdea
      sessionId: string
      prompt: string
      category: string
      sdg: string
      difficulty: string
      ageGroup: string
    }

    if (!idea || !sessionId) {
      return NextResponse.json({ success: false, error: 'Missing idea or sessionId.' }, { status: 400 })
    }

    const supabase = await createClient()

    const { data, error } = await supabase
      .from('saved_ideas')
      .insert({
        session_id: sessionId,
        title: idea.title,
        tagline: idea.tagline,
        the_problem: idea.the_problem,
        the_solution: idea.the_solution,
        target_audience: idea.target_audience,
        monetization: idea.monetization,
        free_build_stack: idea.free_build_stack,
        first_three_steps: idea.first_three_steps,
        prompt,
        category,
        sdg,
        difficulty,
        age_group: ageGroup,
      })
      .select('id')
      .single()

    if (error) throw new Error(error.message)

    return NextResponse.json({ success: true, id: data.id }, { status: 200 })
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to save idea.'
    console.error('[BloopLabs Save Error]', message)
    return NextResponse.json({ success: false, error: message }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { id, sessionId } = await req.json()
    if (!id || !sessionId) {
      return NextResponse.json({ success: false, error: 'Missing id or sessionId.' }, { status: 400 })
    }

    const supabase = await createClient()
    const { error } = await supabase
      .from('saved_ideas')
      .delete()
      .eq('id', id)
      .eq('session_id', sessionId)

    if (error) throw new Error(error.message)

    return NextResponse.json({ success: true }, { status: 200 })
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to delete idea.'
    return NextResponse.json({ success: false, error: message }, { status: 500 })
  }
}
