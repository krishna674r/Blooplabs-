import { NextRequest, NextResponse } from 'next/server'
import { generateStartupIdea, type IdeaFilters } from '@/services/geminiService'

export const runtime = 'nodejs'
export const maxDuration = 30

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()

    const filters: IdeaFilters = {
      prompt: String(body.prompt ?? '').trim(),
      category: String(body.category ?? 'Any Category'),
      sdg: String(body.sdg ?? 'Any SDG'),
      difficulty: String(body.difficulty ?? 'Any Difficulty'),
      ageGroup: String(body.ageGroup ?? 'Any Age Group'),
      stealthMode: Boolean(body.stealthMode ?? false),
    }

    const idea = await generateStartupIdea(filters)

    return NextResponse.json({ success: true, idea }, { status: 200 })
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'An unexpected error occurred.'

    console.error('[BloopLabs API Error]', message)

    return NextResponse.json(
      { success: false, error: message },
      { status: 500 },
    )
  }
}
