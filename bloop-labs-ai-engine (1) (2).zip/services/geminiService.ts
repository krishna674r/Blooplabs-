import { GoogleGenerativeAI } from '@google/generative-ai'

export interface IdeaFilters {
  prompt: string
  category: string
  sdg: string
  difficulty: string
  ageGroup: string
  stealthMode: boolean
}

export interface StartupIdea {
  title: string
  tagline: string
  the_problem: string
  the_solution: string
  target_audience: string
  monetization: string[]
  free_build_stack: {
    frontend: string
    database: string
    automation: string
  }
  first_three_steps: string[]
}

const SYSTEM_PROMPT = `You are a world-class startup incubator director and a brutally honest venture capitalist. Your job is to help young innovators and students find highly unique, viable, and actionable business ideas.

The user will provide you with a specific industry, interest, or set of filters (e.g., budget, difficulty, target audience). Based on these inputs, you must generate ONE hyper-specific startup idea.

CRITICAL RULES & NEGATIVE INSTRUCTIONS (DO NOT IGNORE):
1. NO CLICHÉS: You are strictly banned from generating generic ideas like to-do apps, AI wrappers, basic clothing brands, dropshipping stores, crypto/NFT projects, or basic social media networks.
2. FOCUS ON "UNSEXY" PROBLEMS: Look for deep, real-world friction. Focus on niche B2B problems, local business inefficiencies, legacy industry automation, or hyper-specific creator economy tools.
3. ZERO BUDGET: The solution must be something a student can build and launch for $0 using no-code tools or free-tier software.

OUTPUT FORMAT:
You must return the result STRICTLY as a valid JSON object. Do not include markdown formatting like \`\`\`json or any conversational text before or after the JSON. Use exactly this schema:

{
  "title": "A catchy, modern 1-2 word name for the startup",
  "tagline": "A punchy 5-7 word pitch (e.g., 'Dynamic pricing for local bakeries')",
  "the_problem": "A 2-sentence explanation of the painful, real-world issue being solved.",
  "the_solution": "How this specific product fixes the problem simply and elegantly.",
  "target_audience": "Who exactly has this problem and is desperate enough to pay for it?",
  "monetization": [
    "Specific Revenue Stream 1",
    "Specific Revenue Stream 2"
  ],
  "free_build_stack": {
    "frontend": "A free tool (e.g., Carrd, Vercel)",
    "database": "A free tool (e.g., Airtable, Supabase)",
    "automation": "A free tool (e.g., Make.com)"
  },
  "first_three_steps": [
    "Step 1: Exactly how to validate the idea today for free.",
    "Step 2: How to build the MVP.",
    "Step 3: Where to get the first 10 users (be specific, name the platform/subreddit)."
  ]
}`

export async function generateStartupIdea(filters: IdeaFilters): Promise<StartupIdea> {
  const apiKey = process.env.GEMINI_API_KEY
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in environment variables.')
  }

  const genAI = new GoogleGenerativeAI(apiKey)

  const userPrompt = buildUserPrompt(filters)
  const fullPrompt = `${SYSTEM_PROMPT}\n\n---\n\nUSER INPUT:\n${userPrompt}`

  // Model cascade: try each in order until one succeeds (handles per-model quota limits)
  const MODEL_CASCADE = [
    'gemini-2.5-flash-lite',
    'gemini-2.0-flash-lite',
    'gemini-2.5-flash',
  ]

  let rawText = ''
  let lastError: Error | null = null

  for (const modelName of MODEL_CASCADE) {
    try {
      const model = genAI.getGenerativeModel({ model: modelName })
      const result = await model.generateContent(fullPrompt)
      rawText = result.response.text().trim()
      break
    } catch (err: unknown) {
      lastError = err instanceof Error ? err : new Error(String(err))
      // Only continue cascade on rate-limit / quota errors
      if (lastError.message.includes('429') || lastError.message.includes('quota')) {
        continue
      }
      throw lastError
    }
  }

  if (!rawText) {
    throw new Error(
      lastError?.message ?? 'All Gemini models are currently rate-limited. Please try again in a minute.',
    )
  }

  // Strip any accidental markdown code fences the model may add
  const cleaned = rawText
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim()

  let parsed: StartupIdea
  try {
    parsed = JSON.parse(cleaned)
  } catch {
    throw new Error(
      `Gemini returned non-JSON output. Raw response: ${cleaned.slice(0, 400)}`,
    )
  }

  // Validate required fields exist
  if (!parsed.title || !parsed.tagline || !parsed.the_problem) {
    throw new Error('Gemini response is missing required fields. Please try again.')
  }

  return parsed
}

function buildUserPrompt(filters: IdeaFilters): string {
  const parts: string[] = []

  if (filters.prompt && filters.prompt.trim()) {
    parts.push(`Core interest or industry: "${filters.prompt.trim()}"`)
  }

  if (filters.category && filters.category !== 'Any Category') {
    parts.push(`Category focus: ${filters.category}`)
  }

  if (filters.sdg && filters.sdg !== 'Any SDG') {
    parts.push(`UN Sustainable Development Goal alignment: ${filters.sdg}. The startup idea should contribute toward or address this SDG.`)
  }

  if (filters.difficulty && filters.difficulty !== 'Any Difficulty') {
    parts.push(`Founder technical difficulty level: ${filters.difficulty}`)
  }

  if (filters.ageGroup && filters.ageGroup !== 'Any Age Group') {
    parts.push(`Target age group for founder: ${filters.ageGroup}`)
  }

  if (filters.stealthMode) {
    parts.push(
      'STEALTH MODE ACTIVE: Focus ONLY on boring, niche B2B enterprise problems. Ignore consumer-facing or trendy ideas entirely. Find problems that are painful and lucrative but look unglamorous on the surface.',
    )
  }

  if (parts.length === 0) {
    parts.push('Generate a random, highly original startup idea from any industry you find most promising for a zero-budget student founder.')
  }

  return parts.join('\n')
}
